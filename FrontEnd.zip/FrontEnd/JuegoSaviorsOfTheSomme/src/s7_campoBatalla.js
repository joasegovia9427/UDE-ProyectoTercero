var ultimaTeclaPresionada;
var spotlight;

export default class s7_campoBatalla extends Phaser.Scene {
    constructor() {
        super({key: "s7_campoBatalla", active: true});
    }
    preload() {
        ////------------IMAGENES INICIO----------------------------------
        this.load.image("piso","./assets/images/texturas/campoDeBatallaPiso.png");
        
        this.load.image("separacion","./assets/images/texturas/separacion.png");
        
        this.load.image("avionNegro","./assets/images/objetos/airplane_1 -cuadrada.png");
        
        this.load.image('mask', './assets/images/mapaCapaOculta/mask1.png');
        this.load.image('maskb', './assets/images/mapaCapaOculta/mask1b.png');
        this.load.image('nada', './assets/images/mapaCapaOculta/nada.png');

        ////------------IMAGENES FIN----------------------------------
        


        ////------------SPRITESHEET INICIO----------------------------------
        
        ////------------SPRITESHEET FIN----------------------------------
        


        ////------------MUSICA y SONIDOS INICIO----------------------------------
        
        ////------------MUSICA y SONIDOS FIN----------------------------------
    } 

    

    create() {
        //alert(nav_width + "  x  " + nav_height);
        

        let graphics = this.add.graphics();
        graphics.fillStyle(0x000000, 1);
        graphics.fillRect(20, 20, nav_width*0.90, nav_height*0.38);
 
        let graphics2 = this.add.graphics();
        graphics2.fillStyle(0x535353, 1);
        graphics2.fillRect(20, nav_height*0.38, nav_width*0.90, nav_height*0.10);

        let graphics1 = this.add.graphics();
        graphics2.fillStyle(0x000000, 1);
        graphics2.fillRect(20, nav_height*0.48, nav_width*0.90, nav_height*0.38);


        ////CREACION CAMPO ALIADO

        this.pisoAliado = this.physics.add.image(20, nav_height*0.48, "piso").setDisplayOrigin(0, 0);

        this.pisoAliado.displayWidth = nav_width*0.90;
        this.pisoAliado.displayHeight = nav_height*0.38; 




        ////CREACION CAMPO ENEMIGO
        this.pisoEnemigo = this.physics.add.image(20, 20, "piso").setDisplayOrigin(0, 0);
        
        this.pisoEnemigo.displayWidth = nav_width*0.90;
        this.pisoEnemigo.displayHeight = nav_height*0.38; 





        /////CREACION DE MI BASE::



        ////CREACION DE MI AVION:: aviones aliadas A_x
        this.avionA_1 = this.physics.add.image(100,100,"avionNegro");//.setDisplayOrigin(0, 0);
        this.avionA_1.setCollideWorldBounds(true);
        this.avionA_1.setBounce(0);
        this.avionA_1.scaleX=0.2;
        this.avionA_1.scaleY=0.2;
        /* this.avionA_1.z = 100; */


        ////CREACION DE MASCARA
        spotlight = this.make.sprite({
            x: 0,
            y: 0,
            key: 'mask',
            add: false,
        });
        this.pisoEnemigo.mask = new Phaser.Display.Masks.BitmapMask(this, spotlight);



        ////CREACION SEPARACION DE CAMPOS
        this.pisoEnemigo = this.physics.add.image(15, nav_height*0.28, "separacion").setDisplayOrigin(0, 0);
        
        this.pisoEnemigo.displayWidth = nav_width*0.91;
        this.pisoEnemigo.displayHeight = nav_height*0.30; 
        



        ///// CREACION DE TECLAS
        this.right  = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.D);
        this.left   =  this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.A);
        this.up     = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.W);
        this.down   =  this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.S);
    }






    update(time, delta) {
        
        ///// MOVIMIENTO DE AVION EN BASE A BOTONES
        ////LUEGO SACAR FISICAS PARA FUERA DEL IF DE BOTONES... ya que por mas que no muevas tu avion, tiene que recalcular en base al websockets los eventosasd
        
        
        if(this.right.isDown || this.left.isDown || this.up.isDown || this.down.isDown){
            var vX, vY;
            var diagonal=false;
            if(this.right.isDown) {
                ultimaTeclaPresionada = "right";
                this.avionA_1.x++;
                this.avionA_1.resetFlip();
                if (this.down.isDown){
                    /* this.avionA_1.x++; */
                    this.avionA_1.y++;
                    this.avionA_1.angle=45;
                    vX = 10;vY = 10;
                }else{
                    if (this.up.isDown){
                        /* this.avionA_1.x++; */
                        this.avionA_1.y--;
                        this.avionA_1.angle=-45;
                        vX = 10;vY = -10;
                    }else{this.avionA_1.angle=0;diagonal=true;vX = 10;vY = 0;}
                ;}                
            } else if(this.left.isDown) {
                ultimaTeclaPresionada = "left";
                this.avionA_1.x--;
                this.avionA_1.resetFlip();
                this.avionA_1.flipX=true;
                if (this.down.isDown){
                    /* this.avionA_1.x--; */
                    this.avionA_1.y++;
                    this.avionA_1.angle=-45;
                    vX = -10;vY = 10;
                }else{
                    if (this.up.isDown){
                        /* this.avionA_1.x--; */
                        this.avionA_1.y--;
                        this.avionA_1.angle=45;
                        vX = -10;vY = -10;
                    }else{this.avionA_1.angle=0;diagonal=true; vX = -10;vY = 0;}
                ;}           
            } else if(this.up.isDown) {
                ultimaTeclaPresionada = "up";
                this.avionA_1.y--;
                this.avionA_1.resetFlip();
                this.avionA_1.angle=-90;
                vX = 0;
                vY = -10;
            } else if(this.down.isDown) {
                ultimaTeclaPresionada = "down";
                this.avionA_1.y++;
                this.avionA_1.resetFlip();
                this.avionA_1.angle=90;
                vX = 0;
                vY = 10;
            }
            setVelocidadAvion(this.avionA_1, vX, vY);
            
        }

        //// Actualizacion de mascara en base a avionA_1 x y
        ////Nota: aunque el movimiento de la avion de saque para eventos de boton, esta actualizacion se tiene que hacer constantemente en el update debido a la velocidad del avion (incersia)
        spotlight.x = this.avionA_1.x;
        spotlight.y = this.avionA_1.y;
    }
    
    
}

function setVelocidadAvion(avion, velX, velY){
    if(avion.z == 100){//baja altura
        avion.setVelocity(velX,velY);
    }else{ //200 es altura
        avion.setVelocity(velX/2,velY/2);
    }
}